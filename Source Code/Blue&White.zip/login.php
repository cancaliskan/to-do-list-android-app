<?php
    require("password.php");
    $con = mysqli_connect("localhost:3306", "cancaliskan", "Ee6!r3m7", "cancaliskan_toDoList");
    
    $eposta = $_POST["eposta"];
    $parola = $_POST["parola"];
    
    $statement = mysqli_prepare($con, "SELECT * FROM user WHERE eposta = ? AND parola = ?");
    mysqli_stmt_bind_param($statement, "ss", $eposta, $parola);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $ID, $isim, $eposta, $parola);
    
    $response = array();
    $response["success"] = false;  
    
    while(mysqli_stmt_fetch($statement)){
        if (password_verify($parola, $parola)) {
            $response["success"] = true;  
            $response["isim"] = $isim;
            $response["eposta"] = $eposta;
           // $response["parola"] = $parola;
        }
    }
    echo json_encode($response);
?>