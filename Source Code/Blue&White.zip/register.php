<?php
    $con = mysqli_connect("localhost:3306", "cancaliskan", "Ee6!r3m7", "cancaliskan_toDoList");
    
    $isim = $_POST["isim"];
    $eposta = $_POST["eposta"];
    $parola = $_POST["parola"];
    $statement = mysqli_prepare($con, "INSERT INTO kullanicilar (isim, eposta, parola) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($statement, "sss", $isim, $eposta, $parola);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;  
    
    echo json_encode($response);
?>